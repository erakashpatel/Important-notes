DROP TABLE IF EXISTS `#__test_products`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_test.%');