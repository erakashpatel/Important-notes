<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Helloworld
 * @author     Percept <testing.perceptinfotech@gmail.com>
 * @copyright  2017 Percept
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Include dependancies
jimport('joomla.application.component.controller');

JLoader::registerPrefix('Helloworld', JPATH_COMPONENT);
JLoader::register('HelloworldController', JPATH_COMPONENT . '/controller.php');


// Execute the task.
$controller = JControllerLegacy::getInstance('Helloworld');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
