DROP TABLE IF EXISTS `#__helloworld_category`;
