<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Helloworld
 * @author     Percept <testing.perceptinfotech@gmail.com>
 * @copyright  2017 Percept
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Category controller class.
 *
 * @since  1.6
 */
class HelloworldControllerCategory extends JControllerForm
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'categorys';
		parent::__construct();
	}
}
