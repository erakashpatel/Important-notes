<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Helloworld
 * @author      <>
 * @copyright  Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Product controller class.
 *
 * @since  1.6
 */
class HelloworldControllerProduct extends JControllerForm
{
	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'products';
		parent::__construct();
	}
}
