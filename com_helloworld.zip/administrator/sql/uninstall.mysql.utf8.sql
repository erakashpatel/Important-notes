DROP TABLE IF EXISTS `#__helloworld_products`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_helloworld.%');