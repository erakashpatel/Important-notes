<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Helloworld
 * @author      <>
 * @copyright  Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_helloworld');
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_helloworld')) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>
<?php if ($this->item) : ?>

	<div class="item_fields">
		<table class="table">
			<tr>
			<th><?php echo JText::_('COM_HELLOWORLD_FORM_LBL_PRODUCT_NAME'); ?></th>
			<td><?php echo $this->item->name; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_HELLOWORLD_FORM_LBL_PRODUCT_IMAGE'); ?></th>
			<td>
			<?php
			foreach ((array) $this->item->image as $singleFile) : 
				if (!is_array($singleFile)) : 
					$uploadPath = 'images' . DIRECTORY_SEPARATOR . $singleFile;
					 echo '<a href="' . JRoute::_(JUri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
				endif;
			endforeach;
		?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_HELLOWORLD_FORM_LBL_PRODUCT_STATE'); ?></th>
			<td>
			<i class="icon-<?php echo ($this->item->state == 1) ? 'publish' : 'unpublish'; ?>"></i></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_HELLOWORLD_FORM_LBL_PRODUCT_CREATED_BY'); ?></th>
			<td><?php echo $this->item->created_by_name; ?></td>
</tr>
<tr>
			<th><?php echo JText::_('COM_HELLOWORLD_FORM_LBL_PRODUCT_MODIFIED_BY'); ?></th>
			<td><?php echo $this->item->modified_by_name; ?></td>
</tr>

		</table>
	</div>
	<?php if($canEdit && $this->item->checked_out == 0): ?>
		<a class="btn" href="<?php echo JRoute::_('index.php?option=com_helloworld&task=product.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_HELLOWORLD_EDIT_ITEM"); ?></a>
	<?php endif; ?>
								<?php if(JFactory::getUser()->authorise('core.delete','com_helloworld')):?>
									<a class="btn" href="<?php echo JRoute::_('index.php?option=com_helloworld&task=product.remove&id=' . $this->item->id, false, 2); ?>"><?php echo JText::_("COM_HELLOWORLD_DELETE_ITEM"); ?></a>
								<?php endif; ?>
	<?php
else:
	echo JText::_('COM_HELLOWORLD_ITEM_NOT_LOADED');
endif;
